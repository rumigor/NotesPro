package com.lenecoproekt.notespro.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.lenecoproekt.notespro.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}